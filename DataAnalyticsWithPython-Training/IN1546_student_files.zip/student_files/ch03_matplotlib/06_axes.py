import matplotlib.pyplot as plt

figure = plt.figure(figsize=(8, 4), facecolor='#ccccff')
figure.add_axes((0.2, 0.2, 0.6, 0.6), facecolor='#ffffcc')
plt.show()
